#include "Commands.h"
#include "Chat.h"
#include "String_.h"
#include "Event.h"
#include "Game.h"
#include "Logger.h"
#include "Server.h"
#include "World.h"
#include "Inventory.h"
#include "Entity.h"
#include "Window.h"
#include "Graphics.h"
#include "Funcs.h"
#include "Block.h"
#include "EnvRenderer.h"
#include "Utils.h"
#include "TexturePack.h"
#include "Options.h"
#include "Drawer2D.h"
#include "Audio.h"
#include "Platform.h"
#include "ExtMath.h"
#include "Gui.h"

#define COMMANDS_PREFIX "/client"
#define COMMANDS_PREFIX_SPACE "/client "
static struct ChatCommand* cmds_head;
static struct ChatCommand* cmds_tail;

void Commands_Register(struct ChatCommand* cmd) {
	LinkedList_Append(cmd, cmds_head, cmds_tail);
}

void Commands_Unregister(struct ChatCommand* cmd) {
	struct ChatCommand* cur;
	LinkedList_Remove(cmd, cur, cmds_head, cmds_tail);
}


/*########################################################################################################################*
*------------------------------------------------------Command handling---------------------------------------------------*
*#########################################################################################################################*/
static struct ChatCommand* Commands_FindMatch(const cc_string* cmdName) {
	struct ChatCommand* match = NULL;
	struct ChatCommand* cmd;
	cc_string name;

	for (cmd = cmds_head; cmd; cmd = cmd->next) 
	{
		name = String_FromReadonly(cmd->name);
		if (String_CaselessEquals(&name, cmdName)) return cmd;
	}

	for (cmd = cmds_head; cmd; cmd = cmd->next) 
	{
		name = String_FromReadonly(cmd->name);
		if (!String_CaselessStarts(&name, cmdName)) continue;

		if (match) {
			Chat_Add1("&e/client: Hay varios comandos que empiezan con: \"&f%s&e\".", cmdName);
			return NULL;
		}
		match = cmd;
	}

	if (!match) {
		Chat_Add1("&e/client: Comando desconocido: \"&f%s&e\".", cmdName);
		Chat_AddRaw("&e/client: Escribe &a/client &epara ver la lista de comandos.");
	}
	return match;
}

static void Commands_PrintDefault(void) {
	cc_string str; char strBuffer[STRING_SIZE];
	struct ChatCommand* cmd;
	cc_string name;

	Chat_AddRaw("&eLista de comandos del cliente:");
	String_InitArray(str, strBuffer);

	for (cmd = cmds_head; cmd; cmd = cmd->next) {
		name = String_FromReadonly(cmd->name);

		if ((str.length + name.length + 2) > str.capacity) {
			Chat_Add(&str);
			str.length = 0;
		}
		String_AppendString(&str, &name);
		String_AppendConst(&str, ", ");
	}

	if (str.length) { Chat_Add(&str); }
	Chat_AddRaw("&ePara ver la ayuda de un comando, escribe /client help [comando]");
}

cc_bool Commands_Execute(const cc_string* input) {
	static const cc_string prefixSpace = String_FromConst(COMMANDS_PREFIX_SPACE);
	static const cc_string prefix      = String_FromConst(COMMANDS_PREFIX);
	cc_string text;

	struct ChatCommand* cmd;
	int offset, count;
	cc_string name, value;
	cc_string args[50];

	if (String_CaselessStarts(input, &prefixSpace)) { 
		/* /client [command] [args] */
		offset = prefixSpace.length;
	} else if (String_CaselessEquals(input, &prefix)) { 
		/* /client */
		offset = prefix.length;
	} else if (Server.IsSinglePlayer && String_CaselessStarts(input, &prefix)) {
		/* /client[command] [args] */
		offset = prefix.length;
	} else if (Server.IsSinglePlayer && input->length && input->buffer[0] == '/') {
		/* /[command] [args] */
		offset = 1;
	} else {
		return false;
	}

	text = String_UNSAFE_SubstringAt(input, offset);
	/* Check for only / or /client */
	if (!text.length) { Commands_PrintDefault(); return true; }

	String_UNSAFE_Separate(&text, ' ', &name, &value);
	cmd = Commands_FindMatch(&name);
	if (!cmd) return true;

	if ((cmd->flags & COMMAND_FLAG_SINGLEPLAYER_ONLY) && !Server.IsSinglePlayer) {
		Chat_Add1("&e/client: \"&f%s&e\" solo se puede usar en un jugador.", &name);
		return true;
	}

	if (cmd->flags & COMMAND_FLAG_UNSPLIT_ARGS) {
		/* argsCount = 0 if value.length is 0, 1 otherwise */
		cmd->Execute(&value, value.length != 0);
	} else {
		count = String_UNSAFE_Split(&value, ' ', args, Array_Elems(args));
		cmd->Execute(args,   value.length ? count : 0);
	}
	return true;
}


/*########################################################################################################################*
*------------------------------------------------------Simple commands----------------------------------------------------*
*#########################################################################################################################*/
static void HelpCommand_Execute(const cc_string* args, int argsCount) {
	struct ChatCommand* cmd;
	int i;

	if (!argsCount) { Commands_PrintDefault(); return; }
	cmd = Commands_FindMatch(args);
	if (!cmd) return;

	for (i = 0; i < Array_Elems(cmd->help); i++) {
		if (!cmd->help[i]) continue;
		Chat_AddRaw(cmd->help[i]);
	}
}

static struct ChatCommand HelpCommand = {
	"Help", HelpCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client help [command name]",
		"&eMuestra la ayuda del comando indicado.",
	}
};

static void GpuInfoCommand_Execute(const cc_string* args, int argsCount) {
	char buffer[7 * STRING_SIZE];
	cc_string str, line;
	String_InitArray(str, buffer);
	Gfx_GetApiInfo(&str);
	
	while (str.length) {
		String_UNSAFE_SplitBy(&str, '\n', &line);
		if (line.length) Chat_Add1("&a%s", &line);
	}
}

static struct ChatCommand GpuInfoCommand = {
	"GpuInfo", GpuInfoCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client gpuinfo",
		"&eMuestra información de tu GPU.",
	}
};

static void RenderTypeCommand_Execute(const cc_string* args, int argsCount) {
	int flags;
	if (!argsCount) {
		Chat_AddRaw("&e/client: &cNo indicaste un nuevo tipo de dibujado."); return;
	}

	flags = EnvRenderer_CalcFlags(args);
	if (flags >= 0) {
		EnvRenderer_SetMode(flags);
		Options_Set(OPT_RENDER_TYPE, args);
		Chat_Add1("&e/client: &fEl tipo de dibujado ahora es %s.", args);
	} else {
		Chat_Add1("&e/client: &cTipo de dibujado desconocido &f\"%s\"&c.", args);
	}
}

static struct ChatCommand RenderTypeCommand = {
	"RenderType", RenderTypeCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client rendertype [normal/legacy/fast]",
		"&bnormal: &eModo predeterminado, con todos los efectos del entorno",
		"&blegacy: &eIgual que normal, &cpero suele ser algo más lento",
		"   &eSi las nubes o los bordes del mapa desaparecen al azar, usa este modo",
		"&bfast: &eSacrifica nubes, niebla y cielo para ir más rápido",
	}
};

static void RetroCommand_Execute(const cc_string* args, int argsCount) {
	cc_bool on;
	int level;
	if (!argsCount) {
		Chat_Add1("&e/client retro: &fLas texturas retro están %c&f.", Retro_Enabled ? "&aactivadas" : "&cdesactivadas");
		if (Retro_Enabled) {
			Chat_Add1("&e  Intensidad actual: &f%i &e(1=suave, 2=medio, 3=fuerte)", &Retro_Level);
		}
		return;
	}

	if (String_CaselessEqualsConst(&args[0], "on")) {
		on = true;
		Retro_Enabled = on;
		Options_SetBool(OPT_RETRO, on);
		TexturePack_ExtractCurrent(true);
		Chat_Add1("&e/client retro: &fLas texturas retro ahora están %c&f.", on ? "&aactivadas" : "&cdesactivadas");
		return;
	} else if (String_CaselessEqualsConst(&args[0], "off")) {
		on = false;
		Retro_Enabled = on;
		Options_SetBool(OPT_RETRO, on);
		TexturePack_ExtractCurrent(true);
		Chat_Add1("&e/client retro: &fLas texturas retro ahora están %c&f.", on ? "&aactivadas" : "&cdesactivadas");
		return;
	} else if (String_CaselessEqualsConst(&args[0], "level") || String_CaselessEqualsConst(&args[0], "nivel")) {
		if (argsCount < 2 || !Convert_ParseInt(&args[1], &level) || level < 1 || level > 3) {
			Chat_AddRaw("&e/client retro level [1-3]: &cUsa 1 (suave), 2 (medio) o 3 (fuerte).");
			return;
		}
		Retro_Level = level;
		Options_SetInt(OPT_RETRO_LEVEL, level);
		if (Retro_Enabled) TexturePack_ExtractCurrent(true);
		Chat_Add1("&e/client retro: &fIntensidad del filtro retro puesta en &a%i&f.", &level);
		return;
	} else {
		Chat_AddRaw("&e/client retro: &cUsa &f/client retro on|off &co &f/client retro level [1-3]&c.");
		return;
	}
}

static struct ChatCommand RetroCommand = {
	"Retro", RetroCommand_Execute,
	0,
	{
		"&a/client retro [on/off]",
		"&a/client retro level [1-3]",
		"&eActiva/desactiva o ajusta la intensidad del filtro retro de los 80.",
		"&e1=suave, 2=medio, 3=fuerte. Solo cambia el aspecto de las texturas.",
	}
};

/* ------------------ Classic98 extra commands ------------------ */

static void TimeCommand_Execute(const cc_string* args, int argsCount) {
	struct cc_datetime t;
	cc_string str; char strBuffer[64];
	DateTime_CurrentLocal(&t);
	String_InitArray(str, strBuffer);
	String_Format3(&str, "&eHora local: &f%p2:%p2:%p2", &t.hour, &t.minute, &t.second);
	Chat_Add(&str);
	String_InitArray(str, strBuffer);
	String_Format3(&str, "&eFecha: &f%i/%i/%i", &t.day, &t.month, &t.year);
	Chat_Add(&str);
}

static struct ChatCommand TimeCommand = {
	"Time", TimeCommand_Execute,
	0,
	{
		"&a/client time",
		"&eMuestra la hora real de tu sistema en el chat.",
	}
};

static void DiceCommand_Execute(const cc_string* args, int argsCount) {
	RNGState rnd;
	int sides = 6, result;
	Random_SeedFromCurrentTime(&rnd);

	if (argsCount > 0) {
		if (String_CaselessEqualsConst(&args[0], "coin") || String_CaselessEqualsConst(&args[0], "moneda")) {
			result = Random_Next(&rnd, 2);
			Chat_Add1("&eMoneda: &f%s", result ? "Cara" : "Cruz");
			return;
		}
		if (!Convert_ParseInt(&args[0], &sides) || sides < 2 || sides > 100) {
			Chat_AddRaw("&e/client dice [caras|coin]: &cNúmero de caras entre 2 y 100, o 'coin'.");
			return;
		}
	}
	result = Random_Next(&rnd, sides) + 1;
	Chat_Add2("&eDado (%i caras): &a%i", &sides, &result);
}

static struct ChatCommand DiceCommand = {
	"Dice", DiceCommand_Execute,
	0,
	{
		"&a/client dice [caras]",
		"&a/client dice coin",
		"&eTira un dado (por defecto 6 caras) o una moneda.",
	}
};

static void CalcCommand_Execute(const cc_string* args, int argsCount) {
	double a, b, res;
	char op;
	cc_string expr;
	if (argsCount < 1) {
		Chat_AddRaw("&e/client calc <expresión>: &cEj: 2+3, 10*4, 100/5, 2^8");
		return;
	}
	/* Simple parser for a op b */
	expr = args[0];
	/* Try to find operator */
	int i, found = 0;
	for (i = 1; i < expr.length - 1; i++) {
		char c = expr.buffer[i];
		if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^') {
			op = c;
			cc_string left = String_UNSAFE_Substring(&expr, 0, i);
			cc_string right = String_UNSAFE_SubstringAt(&expr, i + 1);
			if (!Convert_ParseReal(&left, &a) || !Convert_ParseReal(&right, &b)) {
				Chat_AddRaw("&e/client calc: &cNúmeros no válidos.");
				return;
			}
			found = 1;
			break;
		}
	}
	if (!found) {
		Chat_AddRaw("&e/client calc: &cUsa formato número operador número (ej: 5*3)");
		return;
	}
	switch (op) {
		case '+': res = a + b; break;
		case '-': res = a - b; break;
		case '*': res = a * b; break;
		case '/': 
			if (b == 0) { Chat_AddRaw("&e/client calc: &cDivisión por cero."); return; }
			res = a / b; break;
		case '^': res = 1; for (i = 0; i < (int)b; i++) res *= a; break; /* simple integer power */
		default: return;
	}
	Chat_Add1("&eResultado: &a%f", &res);
}

static struct ChatCommand CalcCommand = {
	"Calc", CalcCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client calc <a+b|a-b|a*b|a/b|a^b>",
		"&eCalculadora simple de dos números.",
	}
};

PackedCol Crosshair_Color = PACKEDCOL_WHITE;

static void CrosshairCommand_Execute(const cc_string* args, int argsCount) {
	int r, g, b, scale;
	if (!argsCount) {
		Chat_Add1("&e/client crosshair: &fEscala actual %f1", &Gui.RawCrosshairScale);
		Chat_AddRaw("&e  Color: usa /client crosshair color R G B  (0-255)");
		Chat_AddRaw("&e  Tamaño: /client crosshair size <0.25-5.0>");
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "size") || String_CaselessEqualsConst(&args[0], "tamaño")) {
		if (argsCount < 2 || !Convert_ParseReal(&args[1], &Gui.RawCrosshairScale)) {
			Chat_AddRaw("&e/client crosshair size <número>: &cValor entre 0.25 y 5.0");
			return;
		}
		if (Gui.RawCrosshairScale < 0.25f) Gui.RawCrosshairScale = 0.25f;
		if (Gui.RawCrosshairScale > 5.0f) Gui.RawCrosshairScale = 5.0f;
		Options_SetFloat(OPT_CROSSHAIR_SCALE, Gui.RawCrosshairScale);
		Chat_Add1("&e/client crosshair: &fTamaño puesto en %f1", &Gui.RawCrosshairScale);
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "color") || String_CaselessEqualsConst(&args[0], "colour")) {
		if (argsCount < 4 || !Convert_ParseInt(&args[1], &r) || !Convert_ParseInt(&args[2], &g) || !Convert_ParseInt(&args[3], &b)) {
			Chat_AddRaw("&e/client crosshair color R G B: &cValores 0-255");
			return;
		}
		if (r < 0) r = 0; if (r > 255) r = 255;
		if (g < 0) g = 0; if (g > 255) g = 255;
		if (b < 0) b = 0; if (b > 255) b = 255;
		Crosshair_Color = PackedCol_Make(r, g, b, 255);
		/* Save as hex string for simplicity */
		cc_string colStr; char colBuf[16];
		String_InitArray(colStr, colBuf);
		String_Format3(&colStr, "%i,%i,%i", &r, &g, &b);
		Options_Set(OPT_CROSSHAIR_COLOR, &colStr);
		Chat_Add3("&e/client crosshair: &fColor puesto en &c%i &a%i &b%i", &r, &g, &b);
		return;
	}
	Chat_AddRaw("&e/client crosshair: &cUsa size o color.");
}

static struct ChatCommand CrosshairCommand = {
	"Crosshair", CrosshairCommand_Execute,
	0,
	{
		"&a/client crosshair size <0.25-5>",
		"&a/client crosshair color R G B",
		"&eCambia el tamaño o el color de la mira.",
	}
};

/* Simple waypoints (in-memory + option persist, max 16) */
#define MAX_WAYPOINTS 16
static struct { cc_string name; char nameBuf[32]; float x, y, z; } Waypoints[MAX_WAYPOINTS];
static int Waypoints_Count = 0;

static void Waypoint_Load(void) {
	/* Simple load left for future; starts empty each session for now */
	Waypoints_Count = 0;
}

static void WaypointCommand_Execute(const cc_string* args, int argsCount) {
	int i;
	struct Entity* p = &Entities.CurPlayer->Base;
	if (!argsCount) {
		Chat_AddRaw("&e/client waypoint set|list|remove [nombre]");
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "list") || String_CaselessEqualsConst(&args[0], "lista")) {
		if (Waypoints_Count == 0) {
			Chat_AddRaw("&eNo hay waypoints guardados.");
			return;
		}
		for (i = 0; i < Waypoints_Count; i++) {
			float dx = Waypoints[i].x - p->Position.x;
			float dy = Waypoints[i].y - p->Position.y;
			float dz = Waypoints[i].z - p->Position.z;
			float dist = Math_SqrtF(dx*dx + dy*dy + dz*dz);
			Chat_Add1("&a%s &e-> posición guardada", &Waypoints[i].name);
			Chat_Add1("&e  Distancia aproximada: &f%.1f bloques", &dist);
		}
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "set") || String_CaselessEqualsConst(&args[0], "guardar")) {
		if (argsCount < 2) {
			Chat_AddRaw("&e/client waypoint set [nombre]: &cIndica un nombre.");
			return;
		}
		if (Waypoints_Count >= MAX_WAYPOINTS) {
			Chat_AddRaw("&eLímite de waypoints alcanzado (16).");
			return;
		}
		/* Check duplicate */
		for (i = 0; i < Waypoints_Count; i++) {
			if (String_CaselessEquals(&Waypoints[i].name, &args[1])) {
				Waypoints[i].x = p->Position.x; Waypoints[i].y = p->Position.y; Waypoints[i].z = p->Position.z;
				Chat_Add1("&eWaypoint &a%s &eactualizado.", &args[1]);
				return;
			}
		}
		String_InitArray(Waypoints[Waypoints_Count].name, Waypoints[Waypoints_Count].nameBuf);
		String_Copy(&Waypoints[Waypoints_Count].name, &args[1]);
		Waypoints[Waypoints_Count].x = p->Position.x;
		Waypoints[Waypoints_Count].y = p->Position.y;
		Waypoints[Waypoints_Count].z = p->Position.z;
		Waypoints_Count++;
		Chat_Add1("&eWaypoint &a%s &eguardado.", &args[1]);
		return;
	}
	if (String_CaselessEqualsConst(&args[0], "remove") || String_CaselessEqualsConst(&args[0], "borrar")) {
		if (argsCount < 2) {
			Chat_AddRaw("&e/client waypoint remove [nombre]");
			return;
		}
		for (i = 0; i < Waypoints_Count; i++) {
			if (String_CaselessEquals(&Waypoints[i].name, &args[1])) {
				/* Shift down */
				for (; i < Waypoints_Count - 1; i++) Waypoints[i] = Waypoints[i+1];
				Waypoints_Count--;
				Chat_Add1("&eWaypoint &a%s &eborrado.", &args[1]);
				return;
			}
		}
		Chat_Add1("&eNo existe el waypoint &c%s&e.", &args[1]);
		return;
	}
	Chat_AddRaw("&e/client waypoint: &cUsa set, list o remove.");
}

static struct ChatCommand WaypointCommand = {
	"Waypoint", WaypointCommand_Execute,
	0,
	{
		"&a/client waypoint set [nombre]",
		"&a/client waypoint list",
		"&a/client waypoint remove [nombre]",
		"&eGuarda puntos con nombre. Muestra distancia, no teletransporta.",
	}
};

static void ResolutionCommand_Execute(const cc_string* args, int argsCount) {
	int width, height;
	if (argsCount < 2) {
		Chat_Add4("&e/client: &fLa resolución actual es %i@%f2 x %i@%f2", 
				&Window_Main.Width, &DisplayInfo.ScaleX, &Window_Main.Height, &DisplayInfo.ScaleY);
	} else if (!Convert_ParseInt(&args[0], &width) || !Convert_ParseInt(&args[1], &height)) {
		Chat_AddRaw("&e/client: &cEl ancho y el alto deben ser números enteros.");
	} else if (width <= 0 || height <= 0) {
		Chat_AddRaw("&e/client: &cEl ancho y el alto deben ser mayores que 0.");
	} else {
		Window_SetSize(width, height);
		/* Window_Create uses these, but scales by DPI. Hence DPI unscale them here. */
		Options_SetInt(OPT_WINDOW_WIDTH,  (int)(width  / DisplayInfo.ScaleX));
		Options_SetInt(OPT_WINDOW_HEIGHT, (int)(height / DisplayInfo.ScaleY));
	}
}

static struct ChatCommand ResolutionCommand = {
	"Resolution", ResolutionCommand_Execute,
	0,
	{
		"&a/client resolution [width] [height]",
		"&eFija con precisión el tamaño de la ventana.",
	}
};

static void ModelCommand_Execute(const cc_string* args, int argsCount) {
	if (argsCount) {
		Entity_SetModel(&Entities.CurPlayer->Base, args);
	} else {
		Chat_AddRaw("&e/client model: &cNo indicaste el nombre de un modelo.");
	}
}

static struct ChatCommand ModelCommand = {
	"Model", ModelCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client model [name]",
		"&bnames: &echibi, chicken, creeper, human, pig, sheep",
		"&e       skeleton, spider, zombie, sit, <numerical block id>",
	}
};

static void SkinCommand_Execute(const cc_string* args, int argsCount) {
	if (argsCount) {
		Entity_SetSkin(&Entities.CurPlayer->Base, args);
	} else {
		Chat_AddRaw("&e/client skin: &cNo indicaste el nombre de una skin.");
	}
}

static struct ChatCommand SkinCommand = {
	"Skin", SkinCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client skin [name]",
		"&eCambia tu skin por la del jugador indicado",
		"&a/client skin [url]",
		"&eCambia la skin por una URL que apunte directo a un .PNG",
	}
};

static void ClearDeniedCommand_Execute(const cc_string* args, int argsCount) {
	int count = TextureUrls_ClearDenied();
	Chat_Add1("Se quitaron &e%i &fURLs de texturas rechazadas.", &count);
}

static struct ChatCommand ClearDeniedCommand = {
	"ClearDenied", ClearDeniedCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client cleardenied",
		"&eBorra la lista de URLs de texturas que rechazaste",
	}
};

static void MotdCommand_Execute(const cc_string* args, int argsCount) {
	if (Server.IsSinglePlayer) {
		Chat_AddRaw("&eEste comando solo se puede usar en multijugador.");
		return;
	}
	Chat_Add1("&eNombre: &f%s", &Server.Name);
	Chat_Add1("&eMOTD: &f%s", &Server.MOTD);
}

static struct ChatCommand MotdCommand = {
	"Motd", MotdCommand_Execute,
	COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client motd",
		"&eMuestra el nombre y el MOTD del servidor."
	}
};

/*#######################################################################################################################*
*-------------------------------------------------------PlaceCommand-----------------------------------------------------*
*########################################################################################################################*/

static void PlaceCommand_Execute(const cc_string* args, int argsCount) {
	cc_string name;
	cc_uint8 off;
	int block;
	IVec3 pos;
	
	if (argsCount == 2) {
		Chat_AddRaw("&eFaltan argumentos.");
		return;
	}
	
	block = !argsCount || argsCount == 3 ? Inventory_SelectedBlock : Block_Parse(&args[0]);
	
	if (block == -1) {
		Chat_AddRaw("&eNo se pudo leer el bloque.");
		return;
	}
	if (block > Game_Version.MaxCoreBlock && !Block_IsCustomDefined(block)) {
		Chat_Add1("&eNo existe un bloque con id \"%i\".", &block); 
		return;
	}
	
	if (argsCount > 2) {
		off = argsCount == 4;
		if (!Convert_ParseInt(&args[0 + off], &pos.x) || !Convert_ParseInt(&args[1 + off], &pos.y) || !Convert_ParseInt(&args[2 + off], &pos.z)) {
			Chat_AddRaw("&eNo se pudieron leer las coordenadas.");
			return;
		}
	} else {
		IVec3_Floor(&pos, &Entities.CurPlayer->Base.Position);
	}
	
	if (!World_Contains(pos.x, pos.y, pos.z)) {
		Chat_AddRaw("&eLas coordenadas están fuera de los límites del mundo.");
		return;
	}
	
	Game_ChangeBlock(pos.x, pos.y, pos.z, block);
	name = Block_UNSAFE_GetName(block);
	Chat_Add4("&eBloque %s colocado en (%i, %i, %i).", &name, &pos.x, &pos.y, &pos.z);
}

static struct ChatCommand PlaceCommand = {
	"Place", PlaceCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY,
	{
		"&a/client place [block] [x y z]",
		"&eColoca un bloque en [x y z].",
		"&eSi no indicas bloque, se usa el que llevas en la mano.",
		"&eSi no indicas coordenadas, se usan",
		"&e las coordenadas actuales."
	}
};

/*########################################################################################################################*
*-------------------------------------------------------DrawOpCommand-----------------------------------------------------*
*#########################################################################################################################*/
static IVec3 drawOp_mark1, drawOp_mark2;
static cc_bool drawOp_persist, drawOp_hooked, drawOp_hasMark1;
static const char* drawOp_name;
static void (*drawOp_Func)(IVec3 min, IVec3 max);

static void DrawOpCommand_BlockChanged(void* obj, IVec3 coords, BlockID old, BlockID now);
static void DrawOpCommand_ResetState(void) {
	if (drawOp_hooked) {
		Event_Unregister_(&UserEvents.BlockChanged, NULL, DrawOpCommand_BlockChanged);
		drawOp_hooked = false;
	}

	drawOp_hasMark1 = false;
}

static void DrawOpCommand_Begin(void) {
	cc_string msg; char msgBuffer[STRING_SIZE];
	String_InitArray(msg, msgBuffer);

	String_Format1(&msg, "&e%c: &fColoca o borra un bloque.", drawOp_name);
	Chat_AddOf(&msg, MSG_TYPE_CLIENTSTATUS_1);

	Event_Register_(&UserEvents.BlockChanged, NULL, DrawOpCommand_BlockChanged);
	drawOp_hooked = true;
}


static void DrawOpCommand_Execute(void) {
	IVec3 min, max;

	IVec3_Min(&min, &drawOp_mark1, &drawOp_mark2);
	IVec3_Max(&max, &drawOp_mark1, &drawOp_mark2);
	if (!World_Contains(min.x, min.y, min.z)) return;
	if (!World_Contains(max.x, max.y, max.z)) return;

	drawOp_Func(min, max);
}

static void DrawOpCommand_BlockChanged(void* obj, IVec3 coords, BlockID old, BlockID now) {
	cc_string msg; char msgBuffer[STRING_SIZE];
	String_InitArray(msg, msgBuffer);
	Game_UpdateBlock(coords.x, coords.y, coords.z, old);

	if (!drawOp_hasMark1) {
		drawOp_mark1    = coords;
		drawOp_hasMark1 = true;

		String_Format4(&msg, "&e%c: &fMarca 1 colocada en (%i, %i, %i), coloca la marca 2.", 
						drawOp_name, &coords.x, &coords.y, &coords.z);
		Chat_AddOf(&msg, MSG_TYPE_CLIENTSTATUS_1);
	} else {
		drawOp_mark2 = coords;

		DrawOpCommand_Execute();
		DrawOpCommand_ResetState();

		if (!drawOp_persist) {			
			Chat_AddOf(&String_Empty, MSG_TYPE_CLIENTSTATUS_1);
		} else {
			DrawOpCommand_Begin();
		}
	}
}

static const cc_string yes_string = String_FromConst("yes");
static void DrawOpCommand_ExtractPersistArg(cc_string* value) {
	drawOp_persist = false;
	if (!String_CaselessEnds(value, &yes_string)) return;

	drawOp_persist = true; 
	value->length  -= 3;
	String_UNSAFE_TrimEnd(value);
}

static int DrawOpCommand_ParseBlock(const cc_string* arg) {
	int block = Block_Parse(arg);

	if (block == -1) {
		Chat_Add2("&e%c: &c\"%s\" no es un nombre ni un id de bloque válido.", drawOp_name, arg); 
		return -1;
	}

	if (block > Game_Version.MaxCoreBlock && !Block_IsCustomDefined(block)) {
		Chat_Add2("&e%c: &cNo existe un bloque con id \"%s\".", drawOp_name, arg); 
		return -1;
	}
	return block;
}


/*########################################################################################################################*
*-------------------------------------------------------CuboidCommand-----------------------------------------------------*
*#########################################################################################################################*/
static int cuboid_block;

static void CuboidCommand_Draw(IVec3 min, IVec3 max) {
	BlockID toPlace;
	int x, y, z;

	toPlace = (BlockID)cuboid_block;
	if (cuboid_block == -1) toPlace = Inventory_SelectedBlock;

	for (y = min.y; y <= max.y; y++) {
		for (z = min.z; z <= max.z; z++) {
			for (x = min.x; x <= max.x; x++) {
				Game_ChangeBlock(x, y, z, toPlace);
			}
		}
	}
}

static void CuboidCommand_Execute(const cc_string* args, int argsCount) {
	cc_string value = *args;

	DrawOpCommand_ResetState();
	drawOp_name = "Cuboid";
	drawOp_Func = CuboidCommand_Draw;

	DrawOpCommand_ExtractPersistArg(&value);
	cuboid_block = -1; /* Default to cuboiding with currently held block */

	if (value.length) {
		cuboid_block = DrawOpCommand_ParseBlock(&value);
		if (cuboid_block == -1) return;
	}

	DrawOpCommand_Begin();
}

static struct ChatCommand CuboidCommand = {
	"Cuboid", CuboidCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client cuboid [block] [persist]",
		"&eRellena con [block] el prisma entre dos puntos.",
		"&eSi no indicas bloque, usa el que llevas en la mano.",
		"&e  Si indicas persist y es \"yes\", el comando",
		"&e  se repetirá sin tener que escribirlo de nuevo.",
	}
};


/*########################################################################################################################*
*-------------------------------------------------------ReplaceCommand-----------------------------------------------------*
*#########################################################################################################################*/
static int replace_source, replace_target;

static void ReplaceCommand_Draw(IVec3 min, IVec3 max) {
	BlockID cur, source, toPlace;
	int x, y, z;

	source  = (BlockID)replace_source;
	toPlace = (BlockID)replace_target;
	if (replace_target == -1) toPlace = Inventory_SelectedBlock;

	for (y = min.y; y <= max.y; y++) {
		for (z = min.z; z <= max.z; z++) {
			for (x = min.x; x <= max.x; x++) {
				cur = World_GetBlock(x, y, z);
				if (cur != source) continue;
				Game_ChangeBlock(x, y, z, toPlace);
			}
		}
	}
}

static void ReplaceCommand_Execute(const cc_string* args, int argsCount) {
	cc_string value = *args;
	cc_string parts[2];
	int count;

	DrawOpCommand_ResetState();
	drawOp_name = "Replace";
	drawOp_Func = ReplaceCommand_Draw;

	DrawOpCommand_ExtractPersistArg(&value);
	replace_target = -1; /* Default to replacing with currently held block */

	if (!value.length) {
		Chat_AddRaw("&eReplace: &cSe requiere al menos un argumento"); return;
	}
	count = String_UNSAFE_Split(&value, ' ', parts, 2);

	replace_source = DrawOpCommand_ParseBlock(&parts[0]);
	if (replace_source == -1) return;

	if (count > 1) {
		replace_target = DrawOpCommand_ParseBlock(&parts[1]);
		if (replace_target == -1) return;
	}

	DrawOpCommand_Begin();
}

static struct ChatCommand ReplaceCommand = {
	"Replace", ReplaceCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client replace [source] [replacement] [persist]",
		"&eReemplaza todos los bloques [source] entre dos puntos por [replacement].",
		"&eSi no indicas [replacement], usa el bloque que llevas en la mano.",
		"&e  Si indicas persist y es \"yes\", el comando",
		"&e  se repetirá sin tener que escribirlo de nuevo.",
	}
};


/*########################################################################################################################*
*------------------------------------------------------TeleportCommand----------------------------------------------------*
*#########################################################################################################################*/
static void TeleportCommand_Execute(const cc_string* args, int argsCount) {
	struct Entity* e = &Entities.CurPlayer->Base;
	struct LocationUpdate update;
	Vec3 v;

	if (argsCount != 3) {
		Chat_AddRaw("&e/client teleport: &cNo indicaste las coordenadas X, Y y Z.");
		return;
	}
	if (!Convert_ParseFloat(&args[0], &v.x) || !Convert_ParseFloat(&args[1], &v.y) || !Convert_ParseFloat(&args[2], &v.z)) {
		Chat_AddRaw("&e/client teleport: &cLas coordenadas deben ser números decimales");
		return;
	}

	update.flags = LU_HAS_POS;
	update.pos   = v;
	e->VTABLE->SetLocation(e, &update);
}

static struct ChatCommand TeleportCommand = {
	"TP", TeleportCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY,
	{
		"&a/client tp [x y z]",
		"&eTe mueve a las coordenadas indicadas.",
	}
};


/*########################################################################################################################*
*------------------------------------------------------BlockEditCommand----------------------------------------------------*
*#########################################################################################################################*/
static cc_bool BlockEditCommand_GetInt(const cc_string* str, const char* name, int* value, int min, int max) {
	if (!Convert_ParseInt(str, value)) {
		Chat_Add1("&eBlockEdit: &e%c debe ser un número entero", name);
		return false;
	}

	if (*value < min || *value > max) {
		Chat_Add3("&eBlockEdit: &e%c debe estar entre %i y %i", name, &min, &max);
		return false;
	}
	return true;
}

static cc_bool BlockEditCommand_GetTexture(const cc_string* str, int* tex) {
	return BlockEditCommand_GetInt(str, "Texture", tex, 0, ATLAS1D_MAX_ATLASES - 1);
}

static cc_bool BlockEditCommand_GetCoords(const cc_string* str, Vec3* coords) {
	cc_string parts[3];
	IVec3 xyz;

	int numParts = String_UNSAFE_Split(str, ' ', parts, 3);
	if (numParts != 3) {
		Chat_AddRaw("&eBlockEdit: &cSe requieren 3 valores para una coordenada (X Y Z)");
		return false;
	}

	if (!BlockEditCommand_GetInt(&parts[0], "Coord. X", &xyz.x, -127, 127)) return false;
	if (!BlockEditCommand_GetInt(&parts[1], "Coord. Y", &xyz.y, -127, 127)) return false;
	if (!BlockEditCommand_GetInt(&parts[2], "Coord. Z", &xyz.z, -127, 127)) return false;

	coords->x = xyz.x / 16.0f;
	coords->y = xyz.y / 16.0f;
	coords->z = xyz.z / 16.0f;
	return true;
}

static cc_bool BlockEditCommand_GetBool(const cc_string* str, const char* name, cc_bool* value) {
	if (String_CaselessEqualsConst(str, "true") || String_CaselessEqualsConst(str, "yes")) {
		*value = true;
		return true;
	}

	if (String_CaselessEqualsConst(str, "false") || String_CaselessEqualsConst(str, "no")) {
		*value = false;
		return true;
	}

	Chat_Add1("&eBlockEdit: &e%c debe ser &ayes &eo &ano", name);
	return false;
}


static void BlockEditCommand_Execute(const cc_string* args, int argsCount__) {
	cc_string parts[3];
	cc_string* prop;
	cc_string* value;
	int argsCount, block, v;
	cc_bool b;
	Vec3 coords;

	if (String_CaselessEqualsConst(args, "properties")) {
		Chat_AddRaw("&ePropiedades de bloque editables:");
		Chat_AddRaw("&a  name &e- Fija el nombre del bloque");
		Chat_AddRaw("&a  all &e- Fija la textura de las seis caras del bloque");
		Chat_AddRaw("&a  sides &e- Fija la textura de las cuatro caras laterales");
		Chat_AddRaw("&a  left/right/front/back/top/bottom &e- Fija una sola textura");
		Chat_AddRaw("&a  collide &e- Fija el modo de colisión del bloque");
		Chat_AddRaw("&a  drawmode &e- Fija el modo de dibujado del bloque");
		Chat_AddRaw("&a  min/max &e- Fija las esquinas mínima/máxima del bloque");
		Chat_AddRaw("&eVe &a/client blockedit properties 2 &epara más propiedades");
		return;
	}
	if (String_CaselessEqualsConst(args, "properties 2")) {
		Chat_AddRaw("&ePropiedades de bloque editables (página 2):");
		Chat_AddRaw("&a  walksound &e- Fija el sonido de pisada del bloque");
		Chat_AddRaw("&a  breaksound &e- Fija el sonido al romper el bloque");
		Chat_AddRaw("&a  fullbright &e- Fija si el bloque está totalmente iluminado");
		Chat_AddRaw("&a  blockslight &e- Fija si el bloque bloquea la luz");
		return;
	}

	argsCount = String_UNSAFE_Split(args, ' ', parts, 3);
	if (argsCount < 3) {
		Chat_AddRaw("&eBlockEdit: &eSe requieren tres argumentos &e(Ve &a/client help blockedit&e)");
		return;
	}

	block = Block_Parse(&parts[0]);
	if (block == -1) {
		Chat_Add1("&eBlockEdit: &c\"%s\" no es un nombre ni un ID de bloque válido", &parts[0]);
		return;
	}

	/* TODO: Redo as an array */
	prop  = &parts[1];
	value = &parts[2];
	if (String_CaselessEqualsConst(prop, "name")) {
		Block_SetName(block, value);
	} else if (String_CaselessEqualsConst(prop, "all")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_SetSide(v, block);
		Block_Tex(block, FACE_YMAX) = v;
		Block_Tex(block, FACE_YMIN) = v;
	} else if (String_CaselessEqualsConst(prop, "sides")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_SetSide(v, block);
	} else if (String_CaselessEqualsConst(prop, "left")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_XMIN) = v;
	} else if (String_CaselessEqualsConst(prop, "right")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_XMAX) = v;
	} else if (String_CaselessEqualsConst(prop, "bottom")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_YMIN) = v;
	}  else if (String_CaselessEqualsConst(prop, "top")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_YMAX) = v;
	} else if (String_CaselessEqualsConst(prop, "front")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_ZMIN) = v;
	} else if (String_CaselessEqualsConst(prop, "back")) {
		if (!BlockEditCommand_GetTexture(value, &v)) return;

		Block_Tex(block, FACE_ZMAX) = v;
	} else if (String_CaselessEqualsConst(prop, "collide")) {
		if (!BlockEditCommand_GetInt(value, "Modo de colisión", &v, 0, COLLIDE_CLIMB)) return;

		Blocks.Collide[block] = v;
	} else if (String_CaselessEqualsConst(prop, "drawmode")) {
		if (!BlockEditCommand_GetInt(value, "Modo de dibujado", &v, 0, DRAW_SPRITE)) return;

		Blocks.Draw[block] = v;
	} else if (String_CaselessEqualsConst(prop, "min")) {
		if (!BlockEditCommand_GetCoords(value, &coords)) return;

		Blocks.MinBB[block] = coords;
	} else if (String_CaselessEqualsConst(prop, "max")) {
		if (!BlockEditCommand_GetCoords(value, &coords)) return;

		Blocks.MaxBB[block] = coords;
	} else if (String_CaselessEqualsConst(prop, "walksound")) {
		if (!BlockEditCommand_GetInt(value, "Sound", &v, 0, SOUND_COUNT - 1)) return;

		Blocks.StepSounds[block] = v;
	} else if (String_CaselessEqualsConst(prop, "breaksound")) {
		if (!BlockEditCommand_GetInt(value, "Sound", &v, 0, SOUND_COUNT - 1)) return;

		Blocks.DigSounds[block]  = v;
	} else if (String_CaselessEqualsConst(prop, "fullbright")) {
		if (!BlockEditCommand_GetBool(value, "Brillo total", &b))  return;
		//TODO: Fix this, brightness isn't just a bool anymore
		Blocks.Brightness[block] = b;
	} else if (String_CaselessEqualsConst(prop, "blockslight")) {
		if (!BlockEditCommand_GetBool(value, "Bloquea la luz", &b)) return;

		Blocks.BlocksLight[block] = b;
	} else {
		Chat_Add1("&eBlockEdit: &ePropiedad desconocida %s &e(Ve &a/client help blockedit&e)", prop);
		return;
	}

	Block_DefineCustom(block, false);
}

static struct ChatCommand BlockEditCommand = {
	"BlockEdit", BlockEditCommand_Execute,
	COMMAND_FLAG_SINGLEPLAYER_ONLY | COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client blockedit [block] [property] [value]",
		"&eEdita la propiedad indicada del bloque indicado",
		"&a/client blockedit properties",
		"&eLista las propiedades de bloque editables",
	}
};


/*########################################################################################################################*
*------------------------------------------------------Commands component-------------------------------------------------*
*#########################################################################################################################*/
static void OnInit(void) {
	Commands_Register(&GpuInfoCommand);
	Commands_Register(&HelpCommand);
	Commands_Register(&RenderTypeCommand);
	Commands_Register(&ResolutionCommand);
	Commands_Register(&RetroCommand);
	Commands_Register(&TimeCommand);
	Commands_Register(&DiceCommand);
	Commands_Register(&CalcCommand);
	Commands_Register(&CrosshairCommand);
	Commands_Register(&WaypointCommand);
	Commands_Register(&ModelCommand);
	Commands_Register(&SkinCommand);
	Commands_Register(&TeleportCommand);
	Commands_Register(&ClearDeniedCommand);
	Commands_Register(&MotdCommand);
	Commands_Register(&PlaceCommand);
	Commands_Register(&BlockEditCommand);
	Commands_Register(&CuboidCommand);
	Commands_Register(&ReplaceCommand);
}

static void OnFree(void) {
	cmds_head = NULL;
}

struct IGameComponent Commands_Component = {
	OnInit, /* Init  */
	OnFree  /* Free  */
};
